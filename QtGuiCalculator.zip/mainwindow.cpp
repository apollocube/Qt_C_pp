#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include "resultdialog.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QObject::connect(ui->aboutButton, &QPushButton::clicked,
                     this, &MainWindow::aboutButtonClicked);
    QObject::connect(this, &MainWindow::computed,
                     this, &MainWindow::showResult);

    QObject::connect(ui->plusButton, &QPushButton::clicked,
                     this, &MainWindow::plusButtonClicked);
    QObject::connect(ui->minusButton, &QPushButton::clicked,
                     this, &MainWindow::minusButtonClicked);
    QObject::connect(ui->timesButton, &QPushButton::clicked,
                     this, &MainWindow::timesButtonClicked);
    QObject::connect(ui->divideButton, &QPushButton::clicked,
                     this, &MainWindow::divideButtonClicked);


}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::aboutButtonClicked(){
    QMessageBox messageBox;
    messageBox.setIconPixmap(QPixmap(":/calculator.png"));
    messageBox.setText("This is a calculator");
    messageBox.setWindowTitle("About");
    messageBox.exec();
}

void MainWindow::showResult(float f){
    if (!results){
        results = new ResultDialog(this);
    }
    results->setResult(f);
    results->exec();
}

MainWindow::Arguments MainWindow::arguments(){
    bool ok1, ok2;
    float a1 = ui->argument1Input->text().toFloat(&ok1);
    float a2 = ui->argument2Input->text().toFloat(&ok2);
    if (!ok1 || !ok2){
        QMessageBox messageBox;
        messageBox.setIconPixmap(QPixmap(":/calculator.png"));
        messageBox.setText("One of entries is not valid.");
        messageBox.setWindowTitle("Error");
        messageBox.exec();
    }
    return Arguments(a1, a2);
}

void MainWindow::plusButtonClicked(){
    Arguments a = arguments();
    emit computed(a.first + a.second);
}

void MainWindow::minusButtonClicked(){
    Arguments a = arguments();
    emit computed(a.first - a.second);
}

void MainWindow::timesButtonClicked(){
    Arguments a = arguments();
    emit computed(a.first * a.second);
}

void MainWindow::divideButtonClicked(){
    Arguments a = arguments();
    emit computed(a.first / a.second);
}


void computed(float f){
    return;
}
